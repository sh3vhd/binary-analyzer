# Reverse Engineering Assistant (Web Workbench)

Professional, desktop-style reverse engineering GUI built with React, Vite, TypeScript, and Tailwind CSS.

## Highlights

- Modular architecture with clear separation:
  - `src/core`: binary parsing, disassembly, string extraction, search
  - `src/services`: settings persistence, plugin registry
  - `src/components`: reusable UI modules (hex viewer, settings dialog)
  - `src/App.tsx`: composition layer for the full workstation UI
- Multi-panel interface:
  - Left panel: metadata and sections
  - Center: hex viewer / disassembly switch
  - Right panel: imports, exports, strings, plugins
  - Bottom: log output
- Tabbed multi-file workflow
- Persistent settings (`localStorage`) and session history
- Plugin manifest loading (`.json`) for future extension model
- Lazy-rendered hex viewer for large files
- Non-blocking async string extraction

## Build And Run

1. Install dependencies:
   - `npm install`
2. Start development server:
   - `npm run dev`
3. Production build:
   - `npm run build`

## Supported Binary Analysis

- PE (`.exe`, `.dll`): metadata, sections, imports, exports, lightweight disassembly
- ELF (`.elf`): metadata, sections, lightweight disassembly
- Raw/unknown binaries: hex + string + search + lightweight disassembly

## Settings Storage

- Settings key: `rea.settings.v1`
- Session key: `rea.session.v1`
- Plugin key: `rea.plugins.v1`

Example configuration is available at:

- `public/example-config.json`

## Notes On Disassembly

This implementation includes a lightweight built-in decoder to keep the app self-contained in the browser and responsive for large files.
The architecture keeps disassembly isolated in `src/core/disassembly.ts` so a Capstone/WebAssembly backend can be swapped in later without UI changes.